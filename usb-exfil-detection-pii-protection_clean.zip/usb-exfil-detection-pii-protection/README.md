# USB Data Exfiltration Detection & PII Protection Model for SMEs

Open-source model for monitoring **USB file activity** and detecting **PII** on Linux endpoints using Python **watchdog**, **regex**, and **Microsoft Presidio**.  
**No credentials are stored in code.** Configure secrets via `.env`.

---

## Features
- Detect removable USB mount/unmount events (polling sample path list)
- Watch directories for new/modified files
- Run PII checks (Regex + Presidio analyzer)
- Send alert emails via Gmail SMTP (uses `.env` values)
- Structured JSONL log output

---

## Quickstart

### 1) Setup
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
cp config/settings.example.json config/settings.json
```

Edit `.env` and `config/settings.json` with your paths and email settings.

### 2) Run
```bash
python src/usb_monitor.py
```

> Default subject: **🔐 USB Exfiltration Alert Detected**

---

## Configuration

### `.env`
```
SMTP_USER=your_gmail_address@gmail.com
SMTP_PASSWORD=your_gmail_app_password
ALERT_TO=security.alerts@example.com
```

Use **Gmail App Passwords** (2FA required). Create at: https://myaccount.google.com/apppasswords

### `config/settings.json`
```json
{
  "watch_paths": ["/media/usb", "/home/USER/Downloads"],
  "log_path": "logs/usb_activity.log",
  "pii_threshold": 0.6
}
```

---

## Security Notes
- `.env` and `config/settings.json` are **gitignored**.
- If you ever commit secrets, rotate them immediately and force-remove history or recreate the repo.

---

## License
MIT © Ramesh Kumar A R