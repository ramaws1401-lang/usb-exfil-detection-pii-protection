import regex as re
from presidio_analyzer import AnalyzerEngine

# Simple regex patterns (add more as needed)
REGEXES = {
    "email": re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
    "india_aadhaar": re.compile(r"\b\d{4}\s?\d{4}\s?\d{4}\b"),
    "india_pan": re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b"),
    "phone": re.compile(r"(?:\+?\d{1,3}[-\s]?)?\d{10}\b"),
}

analyzer = AnalyzerEngine()  # Uses default recognizers

def detect_pii(text: str, threshold: float = 0.6):
    findings = []

    # Regex pass
    for name, pattern in REGEXES.items():
        for m in pattern.finditer(text or ""):
            findings.append({"type": name, "match": m.group(), "start": m.start(), "end": m.end(), "score": 1.0})

    # Presidio pass
    pres = analyzer.analyze(text=text or "", entities=[], language="en")
    for f in pres:
        if f.score >= threshold:
            findings.append({"type": f.entity_type, "start": f.start, "end": f.end, "score": f.score, "match": text[f.start:f.end]})

    return findings