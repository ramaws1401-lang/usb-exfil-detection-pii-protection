import os
import json
import time
import hashlib
from pathlib import Path
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

from pii_detector import detect_pii
from alert_manager import send_email

CONFIG_PATH = "config/settings.json"

def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def file_sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

class Handler(FileSystemEventHandler):
    def __init__(self, cfg):
        self.cfg = cfg
        self.log_path = Path(cfg["log_path"]).resolve()
        self.log_path.parent.mkdir(parents=True, exist_ok=True)

    def _log(self, record: dict):
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def on_created(self, event):
        if event.is_directory:
            return
        self._inspect(Path(event.src_path), action="created")

    def on_modified(self, event):
        if event.is_directory:
            return
        self._inspect(Path(event.src_path), action="modified")

    def _inspect(self, path: Path, action: str):
        try:
            text_preview = ""
            if path.suffix.lower() in {".txt", ".csv", ".log"}:
                text_preview = path.read_text(errors="ignore")[:5000]

            findings = detect_pii(text_preview, threshold=self.cfg.get("pii_threshold", 0.6))
            record = {
                "ts": int(time.time()),
                "action": action,
                "path": str(path),
                "sha256": file_sha256(path),
                "pii_findings": findings,
            }
            self._log(record)

            if findings:
                body = f"Path: {path}\nAction: {action}\nFindings: {findings}\nHash: {record['sha256']}"
                send_email(body)

        except Exception as e:
            self._log({"ts": int(time.time()), "action": "error", "path": str(path), "error": str(e)})

def main():
    cfg = load_config()
    observer = Observer()
    handler = Handler(cfg)
    for p in cfg.get("watch_paths", []):
        Path(p).mkdir(parents=True, exist_ok=True)
        observer.schedule(handler, p, recursive=True)

    observer.start()
    print("[usb-monitor] watching:", cfg.get("watch_paths", []))
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()

if __name__ == "__main__":
    main()